public class Main {
    public static void main(String[] args) {
        int num = 10;   // change the value if needed

        if (num > 0) {
            System.out.println("The number is Positive");
        } else {
            System.out.println("The number is Not Positive");
        }
    }
}
