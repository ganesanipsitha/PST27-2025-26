public class Main {
    public static void main(String[] args) {
        int num = 98;

        if (num % 2 == 0) {
            System.out.println("The number is Even");
        } else {
            System.out.println("The number is Odd");
        }
    }
}
